/* typedef struct Labels
{
    char lab[1000],address[10];
}; 

 */